const configForm = {
  buttonSubmin: '.popup__button-save',
  buttonDisabled: 'popup__button-save_disabled',
  inputBorderError: 'popup__input_data_error',
  inputPopup: '.popup__input',
  popupTextError: '.popup__error',
  buttonClosePopup: '.popup__button-close',
}

export { configForm };


