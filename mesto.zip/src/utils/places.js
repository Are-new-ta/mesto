const initialCards = [
  {
    name: 'Еревавн',
    link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/arkhyz.jpg'
  },
  {
    name: 'Калининград',
    link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/chelyabinsk-oblast.jpg'
  },
  {
    name: 'Дербент',
    link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/ivanovo.jpg'
  },
  {
    name: 'Эльбрус',
    link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/kamchatka.jpg'
  },
  {
    name: 'Санкт-Петербург',
    link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/kholmogorsky-rayon.jpg'
  },
  {
    name: 'Черногория',
    link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/baikal.jpg'
  }
];

<<<<<<< HEAD
export { initialCards };



// const initialCards = [
//   {
//     name: 'Вою на луну',
//     link: 'https://www.boredpanda.com/blog/wp-content/uploads/2018/07/BbxQjM6HycS-png__700.jpg'
//   },
//   {
//     name: 'Утепляемся',
//     link: 'https://avatars.mds.yandex.net/i?id=b25881740c7dec0346f7e3f84af8171d-5906127-images-thumbs&n=13'
//   },
//   {
//     name: 'Перекус',
//     link: 'https://i.mycdn.me/i?r=AzEPZsRbOZEKgBhR0XGMT1Rk_aVSL4oLEB8v0RSdZqXd76aKTM5SRkZCeTgDn6uOyic'
//   },
//   {
//     name: 'Шоппинг',
//     link: 'https://avatars.dzeninfra.ru/get-zen_doc/3986710/pub_5f80a6ed42a69673f78c253d_5f80a7555c2b3403ce27bffc/scale_1200'
//   },
//   {
//     name: 'Тусовочка',
//     link: 'https://avatars.dzeninfra.ru/get-zen_doc/3853921/pub_5f80a6ed42a69673f78c253d_5f80a86eb1a4d95dc0a6fefd/scale_1200'
//   },
//   {
//     name: 'Дела дела',
//     link: 'https://avatars.dzeninfra.ru/get-zen_doc/3545552/pub_5f80a6ed42a69673f78c253d_5f80a771b1a4d95dc0a53560/scale_1200'
//   }
// ];

// export { initialCards };
=======
export { initialCards };
>>>>>>> 68565beb85df5bc1b02026d896ebebdf5592302b
